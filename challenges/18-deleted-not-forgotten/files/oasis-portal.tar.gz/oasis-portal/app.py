from flask import Flask

app = Flask(__name__)


@app.route('/')
def index():
    return 'Oasis Portal'


@app.route('/health')
def health():
    return {'status': 'ok'}
