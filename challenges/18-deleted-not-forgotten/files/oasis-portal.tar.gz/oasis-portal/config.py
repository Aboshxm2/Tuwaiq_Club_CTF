import os

# Payment gateway settings
PAYMENT_API_URL = "https://pay.oasis.example/v1"
PAYMENT_API_KEY = os.environ["PAYMENT_API_KEY"]
