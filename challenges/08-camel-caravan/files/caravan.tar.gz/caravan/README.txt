Welcome to the caravan. The flag is hiding somewhere in here.
